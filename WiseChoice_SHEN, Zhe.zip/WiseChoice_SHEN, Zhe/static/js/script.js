let compareBoxHelper = {
    compareBoxContainer: document.getElementById("compareBox"),
    compareBox: document.getElementById("compareBoxProducts"),
    productIdAttributeName: "data-productid",
    statusOpen: false,
    productList: [],
    showCompareBox: function() {
        compareBoxHelper.statusOpen = true;
        compareBoxHelper.compareBoxContainer.style.display = "block";
    },
    hideCompareBox: function() {
        compareBoxHelper.statusOpen = false;
        compareBoxHelper.compareBoxContainer.style.display = "none";
    },
    addCompare: function (productId, productName, productImage, productUrl) {
        productId = parseInt(productId);
        if (!compareBoxHelper.statusOpen) {
            compareBoxHelper.showCompareBox();
        }
        if (compareBoxHelper.productList.indexOf(productId) !== -1) {
            return true;
        }
        if (compareBoxHelper.productList.length >= 4) {
            alert("最多只能对比四个产品！");
            return false;
        }
        compareBoxHelper.productList.push(productId);
        var rootElement = document.createElement("div");
        rootElement.classList.add("col-3");
        rootElement.setAttribute(compareBoxHelper.productIdAttributeName, productId);
        var cardElement = document.createElement("div");
        cardElement.classList.add("card");
        cardElement.classList.add("h-100");
        rootElement.append(cardElement);
        var imageElement = document.createElement("img");
        imageElement.classList.add("card-img-top");
        imageElement.classList.add("mx-auto");
        imageElement.classList.add("my-2");
        imageElement.style.maxHeight = "6rem";
        imageElement.style.width = "auto";
        imageElement.setAttribute("src", productImage);
        imageElement.setAttribute("alt", "product image");
        var cardBodyElement = document.createElement("div");
        cardBodyElement.classList.add("card-body");
        cardBodyElement.classList.add("d-flex");
        cardBodyElement.classList.add("flex-column");
        var pElement = document.createElement("p");
        pElement.classList.add("card-text");
        pElement.textContent = productName;
        pElement.style.fontSize = "0.8rem";
        var buttonElement = document.createElement("button");
        buttonElement.classList.add("btn");
        buttonElement.classList.add("btn-sm");
        buttonElement.classList.add("btn-outline-danger");
        buttonElement.classList.add("mt-auto");
        buttonElement.textContent = "移除";
        buttonElement.onclick = function () {
            compareBoxHelper.removeCompare(productId);
        };
        cardBodyElement.append(pElement);
        cardBodyElement.append(buttonElement);
        cardElement.append(imageElement);
        cardElement.append(cardBodyElement);
        compareBoxHelper.compareBox.append(rootElement);
        var btnAddCompare = document.getElementById("btnAddCompare" + productId);
        var btnRemoveCompare = document.getElementById("btnRemoveCompare" + productId);
        btnAddCompare.style.display = "none";
        btnRemoveCompare.style.display = "block";
    },
    removeCompare: function (productId) {
        productId = parseInt(productId);
        if (compareBoxHelper.productList.indexOf(productId) === -1) {
            return true;
        }
        let products = compareBoxHelper.compareBox.children;
        for(let i = 0; i < products.length; i++)
        {
            var currentProductId = parseInt(products[i].getAttribute(compareBoxHelper.productIdAttributeName));
            if (currentProductId === productId) {
                compareBoxHelper.compareBox.removeChild(products[i]);
            }
        }
        compareBoxHelper.productList.splice(compareBoxHelper.productList.indexOf(productId), 1);
        var btnAddCompare = document.getElementById("btnAddCompare" + productId);
        var btnRemoveCompare = document.getElementById("btnRemoveCompare" + productId);
        btnAddCompare.style.display = "block";
        btnRemoveCompare.style.display = "none";
    },
    removeAllCompare: function () {
        var productList = compareBoxHelper.productList.slice();
        for(let i = 0; i < productList.length; i++)
        {
            compareBoxHelper.removeCompare(productList[i]);
        }
    },
    startCompare: function () {
        if (compareBoxHelper.productList.length <= 1) {
            alert("请选择两个或以上产品！");
            return false;
        }
        window.open('/product?action=compare&ids=' + compareBoxHelper.productList.toString());
        compareBoxHelper.removeAllCompare();
        compareBoxHelper.hideCompareBox();
    }
};

let ProgressRing = {
    init: function (root) {
        var $circle = root.find('circle:last-child');
        var r = $circle.get(0).r.animVal.value;
        var c = Math.PI * (r * 2);
        var circleDOM = $circle.get(0);
        circleDOM.setAttribute('stroke-dasharray', c + 'px');
        circleDOM.setAttribute('stroke-dashoffset', c + 'px');
        root.find('text:first-child')[0].textContent = "0%";
    },
    setValue: function (root, value, text) {
        var $circle = root.find('circle:last-child');

        if (isNaN(value)) {
            value = 0;
        }
        else {
            var r = $circle.get(0).r.animVal.value;
            var c = Math.PI * (r * 2);

            if (value < 0) { value = 0; }
            if (value > 100) { value = 100; }

            var strokeDasharray = c;
            $circle.css({ strokeDasharray: strokeDasharray });
            var strokeDashoffset = ((100 - value) / 100) * c;
            $circle.css({ strokeDashoffset: strokeDashoffset });
            root.find('text:first-child')[0].textContent = text === undefined ? (value + "%") : text;
        }
    }
};

let StarScorer = {
    render: function (root, value) {
        value = parseInt(value);
        let wrapper = root.getElementsByClassName("star-scorer-wrapper")[0];
        let options = wrapper.getElementsByTagName("span");
        for (let i = 0; i < options.length; i++) {
            let currentValue = parseInt(options[i].getAttribute("value"));
            let classList = options[i].classList;
            if (currentValue * 2 - 1 == value) {
                if (classList.contains("bi-star")) classList.remove("bi-star");
                if (!classList.contains("bi-star-half")) classList.add("bi-star-half");
                if (classList.contains("bi-star-fill")) classList.remove("bi-star-fill");
            } else {
                if (currentValue * 2 - 1 < value) {
                    if (classList.contains("bi-star")) classList.remove("bi-star");
                    if (classList.contains("bi-star-half")) classList.remove("bi-star-half");
                    if (!classList.contains("bi-star-fill")) classList.add("bi-star-fill");
                } else {
                    if (!classList.contains("bi-star")) classList.add("bi-star");
                    if (classList.contains("bi-star-half")) classList.remove("bi-star-half");
                    if (classList.contains("bi-star-fill")) classList.remove("bi-star-fill");
                }
            }
        }
        root.getElementsByClassName("star-scorer-result")[0].textContent = value;
    },
    setValue: function (root, value) {
        let inputObj = root.getElementsByTagName("input")[0];
        inputObj.value = value;
        StarScorer.render(root, inputObj.value);
    },
    getValue: function (e) {
        var rect = e.target.getBoundingClientRect();
        var x = e.clientX - rect.left;
        let value = parseInt(e.target.getAttribute("value"));
        if (x < e.target.offsetWidth / 2) {
            return (value - 1) * 2 + 1;
        } else {
            return value * 2;
        }
    },
    init: function (root) {
        let wrapper = root.getElementsByClassName("star-scorer-wrapper")[0];
        let inputObj = root.getElementsByTagName("input")[0];
        if (!(isNaN(inputObj.value) || inputObj.value.length === 0)) {
            StarScorer.setValue(root, parseInt(inputObj.value));
        } else {
            StarScorer.setValue(root, 0);
        }
        let options = wrapper.getElementsByTagName("span");
        for (let j = 0; j < options.length; j++) {
            options[j].onmousemove = function (e) {
                if (root.getAttribute("disabled") != null ||
                    wrapper.getAttribute("disabled") != null ||
                    e.target.getAttribute("disabled") != null) {
                        return false;
                }
                StarScorer.render(root, StarScorer.getValue(e));
            }
            options[j].onclick = function (e) {
                if (root.getAttribute("disabled") != null ||
                    wrapper.getAttribute("disabled") != null ||
                    e.target.getAttribute("disabled") != null) {
                        return false;
                }
                let value = StarScorer.getValue(e);
                if (parseInt(inputObj.value) === value) {
                    StarScorer.setValue(root, 0);
                } else {
                    StarScorer.setValue(root, value);
                }
                
            };
            wrapper.onmouseleave = function (e) {
                if (root.getAttribute("disabled") != null ||
                    wrapper.getAttribute("disabled") != null ||
                    e.target.getAttribute("disabled") != null) {
                        return false;
                }
                StarScorer.render(root, inputObj.value);
            }
        }
    }
};
